#include <unistd.h>
const ssize_t offset_to_pokedata_workaround=1016;
