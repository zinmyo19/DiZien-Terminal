#!/bin/sh
# Rebuild recipe for the supplied corresponding-source snapshot.
# NOT VALIDATED HERE: review toolchain paths and run in a clean Android NDK environment.
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
NDK=${NDK:?Set NDK to Android NDK r27c}
HOST_TAG=${HOST_TAG:-linux-x86_64}
TOOLCHAIN="$NDK/toolchains/llvm/prebuilt/$HOST_TAG/bin"
export PATH="$TOOLCHAIN:$PATH"
API=24
CFLAGS_COMMON='-O2 -fPIE -DARG_MAX=131072 -D_LARGEFILE64_SOURCE -D__ANDROID__ -ffile-prefix-map=$ROOT=. -fmacro-prefix-map=$ROOT=. -ffile-prefix-map=/workspace=. -fmacro-prefix-map=/workspace=. -ffile-prefix-map=/home/ubuntu=.'
# Build the static allocator from the supplied Android-configured tree.
for ABI in arm64-v8a x86_64; do
  case "$ABI" in
    arm64-v8a) TRIPLE=aarch64-linux-android; CC=${TRIPLE}${API}-clang ;;
    x86_64) TRIPLE=x86_64-linux-android; CC=${TRIPLE}${API}-clang ;;
  esac
  T="$ROOT/talloc-$ABI"; (cd "$T" && ./configure --build="$(./buildtools/bin/waf --help >/dev/null 2>&1; echo unknown)" --host="$TRIPLE" --bundled-libraries=NONE --builtin-libraries=replace --disable-rpath --disable-rpath-install --without-gettext)
  (cd "$T" && make CC="$CC" CFLAGS="$CFLAGS_COMMON -D__STDC_WANT_LIB_EXT1__=1 -include compat.h -include config.h" && ar qf libtalloc.a bin/default/talloc.c*.o bin/default/lib/replace/replace.c*.o)
done
# Rebuild each PRoot executable and its embedded loaders from the corresponding generated tree.
for ABI in arm64-v8a x86_64; do
  case "$ABI" in
    arm64-v8a) CC=aarch64-linux-android${API}-clang ;;
    x86_64) CC=x86_64-linux-android${API}-clang ;;
  esac
  B="$ROOT/proot-build-$ABI"; T="$ROOT/talloc-$ABI"
  (cd "$B" && make clean && make CC="$CC" CPPFLAGS="$CFLAGS_COMMON -D_FILE_OFFSET_BITS=64 -D_GNU_SOURCE -I. -I. -include compat.h -include config.h -I$T" LDFLAGS="-L$T -ltalloc -Wl,-z,noexecstack")
done
# On x86_64, the makefile's loader -m32 invocation must use i686-linux-android24-clang;
# on arm64 it must use armv7a-linux-androideabi24-clang. Do not pass -m32 to those wrappers.
