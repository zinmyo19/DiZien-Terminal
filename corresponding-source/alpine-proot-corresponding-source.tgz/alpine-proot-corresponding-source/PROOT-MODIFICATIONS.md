# PRoot modification record

This archive contains the corresponding source for DZ Terminal's PRoot executable.
The pristine PRoot snapshot is preserved at `provenance/proot-master-upstream-snapshot.tar.gz`; the validated local source identity is commit `e2d843ee6dab076ea0ed1ffd5d0ea12232185499` (from the supplied `alpine-runtime-modern/commit.txt`).

The supplied DZ Terminal source change relative to that pristine snapshot is the existing addition of `#include <string.h>` at the beginning of `extension/ashmem_memfd/ashmem_memfd.c` in both ABI build trees. For the private x86_64 candidate only, dated **2026-10-20**, the four additionally overlaid files implement this narrowly scoped Android compatibility patch: `syscall/enter.c` maps legacy Android x86 `dup2` at entry (using same-fd `fcntl(F_GETFD)` where appropriate); `syscall/exit.c` provides the kernel `SIGSYS` fallback, preserves correct return-value tracking, and retries only the explicitly whitelisted legacy syscalls through existing common handlers when they return `ENOSYS`; `tracee/seccomp.c` and `tracee/tracee.h` carry the matching seccomp/fallback declarations and plumbing. The same-fd path preserves `FD_CLOEXEC`; valid old/new descriptors, invalid `oldfd` (`EBADF`), different-fd clearing of `FD_CLOEXEC`, and the rule that an invalid `oldfd` does not close the target are covered by the raw tests. No broad retry or unrelated modernization is claimed. The ARM64 tree, ARM64 source baseline, JNI, loaders, and all other original source files are unchanged.

The modified files remain under the upstream PRoot GPL-2.0-or-later terms. The archive also contains talloc source under its separate LGPL-3.0-or-later terms; that allocator is not relicensed by this notice.

## Targeted x86_64 rebuild note (2026-10-20)

`X86_64-TARGETED-REBUILD.sh` accepts `NDK` and `SHIPPED_LOADER_DIR`, compiles exactly the supplied `talloc.c` and `memset_compat.c` with Android NDK r27c/API 24, PIC/PIE, 16-KiB page-alignment linker flags, and reproducible prefix maps, then reuses the unchanged shipped x86_64 loaders for the targeted PRoot rebuild. It has no machine-specific absolute paths and does not rebuild ARM64 or loaders.
